import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { LoginComponentComponent } from './Component/login-component/login-component.component';
import { HeaderComponent } from './Component/header/header.component';
import { MainlayoutComponent } from './Component/mainlayout/mainlayout.component';
import { AdminpageComponent } from './Component/adminpage/adminpage.component';
import { HomepageComponent } from './Component/homepage/homepage.component';
import { ProfileComponent } from './Component/profile/profile.component';
import { LoaderComponent } from './Component/loader/loader.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,LoginComponentComponent,HeaderComponent,MainlayoutComponent,AdminpageComponent,HomepageComponent,ProfileComponent,LoaderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'NXActivityTrackerUI';
}
