import { Routes } from '@angular/router';
import { MainlayoutComponent } from './Component/mainlayout/mainlayout.component';
import { LoginComponentComponent } from './Component/login-component/login-component.component';
import { AdminpageComponent } from './Component/adminpage/adminpage.component';
import { AuthGuardService } from './authgaurd.service';
import { HomepageComponent } from './Component/homepage/homepage.component';
import { ProfileComponent } from './Component/profile/profile.component';


export const routes: Routes = [
    { 
        path: '',
        component: MainlayoutComponent ,
        children:[
            {path: '', redirectTo: 'login', pathMatch: 'full'},
            {path:'login',component:LoginComponentComponent}, 
            {path:'admin',component:AdminpageComponent,canActivate: [AuthGuardService]},
            {path:'home',component:HomepageComponent,canActivate:[AuthGuardService]},  
            {path:'profile',component:ProfileComponent,canActivate:[AuthGuardService]} 
        ]
    }
];

