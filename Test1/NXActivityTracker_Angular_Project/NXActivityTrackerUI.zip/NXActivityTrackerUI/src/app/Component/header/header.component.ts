import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoginService } from '../../Service/login.service';
import { UserService } from '../../Service/user.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  
  isDropdownOpen = false;
  userFirstName : string ='';
  userLastName : string ='';
  isRole:boolean = false;

  constructor(private router:Router, public loginservice:LoginService,private userService: UserService){}

  // openOutlook() {
  //   const to = 'omkar.raut@rntbci.com';
  //   const cc = 'arun-pandian.ramakrishnan@rntbci.com'; // You can add multiple with commas
  //   const subject = 'Test Mail';
  //   const body = 'Test Mail';
  //   window.location.href = `mailto:${to}?cc=${cc}&subject=${subject}&body=${body}`;
  // }
  

  ngOnInit() {

    this.userService.user$.subscribe(user => {
      if (user) {
        this.userFirstName = user.firstName;
        this.userLastName = user.lastName;
      }
    });

    this.userService.role$.subscribe(role => {
      this.isRole = role === 'admin';
    });
  

    if (typeof window !== 'undefined') {
      const storedUser = sessionStorage.getItem('firstname_lastname');
      if (storedUser) {
        const userInfo = JSON.parse(storedUser);
       this.userFirstName = userInfo.firstName;
       this.userLastName = userInfo.lastName;
      }

      const getRole = sessionStorage.getItem('details');
      if (getRole) {
        const userInfo = JSON.parse(getRole);
        this.isRole = userInfo.role === 'admin';
        this.userService['userRole'].next(userInfo.role); // trigger observable on refresh
      }
    }    
  }


  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  admin(){
    // this.loginservice.loginTrack();
    this.router.navigate(['/admin']);
  }

  logout(){
    this.loginservice.logoutTrack();    
    this.router.navigate(['/login']);
  }

  homeNavigation(){
    this.router.navigate(['/home']);
  }

  profile(){
    this.router.navigate(['/profile']);
  }
  
}
  

