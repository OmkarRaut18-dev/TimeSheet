import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { LoginService } from '../../Service/login.service';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoaderComponent } from '../loader/loader.component';
import { UserService } from '../../Service/user.service';

@Component({
  selector: 'app-login-component',
  standalone: true,
  imports: [FormsModule,CommonModule,HeaderComponent,HttpClientModule,LoaderComponent],
  templateUrl: './login-component.component.html',
  styleUrl: './login-component.component.css'
})
export class LoginComponentComponent {

  username: string = '';
  password: string = '';
  errorMessage: string = '';
  loading:boolean = false; 

  constructor(private loginService : LoginService,private router:Router,private userService: UserService){}
//private int a = 1;
// private a : int; 
  ngOnInit(){
    this.loginService.logoutTrack(); 
  }  

  onSubmit() {
    if (!this.username || !this.password) {
      alert("Please enter both User ID and Password");
      return;
    }
    
    this.loading = true;
    this.loginService.login(this.username, this.password).subscribe({
      next: (response) => {
        console.log('Login successful', response);
        console.log('Login successful', response.firstName, response.lastName);
        if(response.role == "admin"){
          this.loginService.setIsRoleAdmin(true);
        }
        this.loginService.loginTrack();

        // if (typeof window !== 'undefined') {
        //   const userInfo = {
        //     firstName: response.firstName,
        //     lastName: response.lastName
        //   };
        //   sessionStorage.setItem('firstname_lastname', JSON.stringify(userInfo));
        // }        
        this.userService.setUser(response.firstName, response.lastName, response.role);


        
        if (typeof window !== 'undefined') {
          sessionStorage.setItem('user', JSON.stringify(response.username));  // Save user info in sessionStorage safely
          sessionStorage.setItem('details', JSON.stringify(response));
          
        }
        this.loading = false;
        this.router.navigate(['/home']);
      },
      error: (error) => {
        this.loading = false;
        console.error('Login failed', error);
        alert('Wrong Password, or something went wrong');
      }
    });
  }

}
