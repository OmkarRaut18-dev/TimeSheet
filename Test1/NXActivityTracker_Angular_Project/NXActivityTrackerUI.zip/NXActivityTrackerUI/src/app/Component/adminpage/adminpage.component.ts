import { Component } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { passwordValidator } from '../../password.validator';
import { AdminService } from '../../Service/admin.service';
import { LoaderComponent } from '../loader/loader.component';


@Component({
  selector: 'app-adminpage',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule,FormsModule,LoaderComponent],
  templateUrl: './adminpage.component.html',
  styleUrl: './adminpage.component.css'
})
export class AdminpageComponent {

  constructor(public fb:FormBuilder, public adminService: AdminService){}

  users: any[] = [];
  loading: boolean = false;
  pendingEntriesEmpEmailId :string ="";

  ngOnInit() {
    this.extractListOfDeveloper();
  }

  addUserForm = this.fb.group({
    user_id:['',[Validators.required,Validators.minLength(5)]],
    first_name:['',Validators.required],
    last_name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    role: ['', Validators.required],
    designation: ['', Validators.required],
    RNID: ['', Validators.required],
    created_at: [new Date().toISOString()],
    password: ['', Validators.required],
    confirmPassword: ['', Validators.required],
  },
  {validators: passwordValidator}
);

removeUserForm = this.fb.group({
  userID:['',Validators.required]
})


get designation(){
  return this.addUserForm.get('designation');
}

get RNID(){
  return this.addUserForm.get('RNID');
}


get userId() {
  return this.addUserForm.get('user_id');
}

get role() {
  return this.addUserForm.get('role');
}

get firstName(){
  return this.addUserForm.get('first_name');
}

get lastName(){
  return this.addUserForm.get('last_name');
}

get email(){
  return this.addUserForm.get('email');
}

get passwordValue() {
  return this.addUserForm.get('password');
}

get confirmPassword() {
  return this.addUserForm.get('confirmPassword');
}

get userIDValue(){
  return this.removeUserForm.get('userID');
 }

onSubmit() {  
  if(this.addUserForm.valid){
    console.log(this.addUserForm.value);
    this.loading = true;
    this.adminService.addUserDetails(this.addUserForm.value).subscribe({
     next:(response)=>{
       alert('User added successfully!');
       this.addUserForm.reset();
       this.extractListOfDeveloper();
       this.loading = false;
     },
     error:(error)=>{
      this.loading = false;
       alert('Failed to add user');
     }
    });
  }else{
    this.addUserForm.reset();
    this.loading = false;
    alert('Please fill all required fields');
  }
}

onReset() {
  this.addUserForm.reset();
}

onSubmitToRemoveUser(){
  if(this.removeUserForm.valid){
    const userId = this.removeUserForm.value.userID;
    if(userId != null){
      this.loading = true;
      this.adminService.removeUser(userId).subscribe({
        next:(response)=>{
          this.removeUserForm.reset();
          this.extractListOfDeveloper();
          this.loading = false;
          alert('User successfully removed');          
        },
        error:(error)=>{
          this.removeUserForm.reset();
          this.loading = false;
          alert('Please fill all required fields');
        }
      })   
     }  
  } 
}

onRestRemoveUser(){
  this.removeUserForm.reset();
}

extractListOfDeveloper(){
  this.loading = true;
  this.adminService.fetchListOfDeveloper().subscribe({
    next:(response)=>{
      console.log(response);
      this.users = response;  
      
      this.pendingEntriesEmpEmailId = this.users
      .filter(user => user.statusOfEntries?.includes('Pending entries for'))
      .map(user => user.email)
      .join('; ');       
      this.loading = false;           
    },
    error:(error)=>{
      this.loading = false;
      console.error('Failed to fetch user data', error);
    }
  })
}

draftMail() {  
  this.loading = true;
  if(this.pendingEntriesEmpEmailId != null && this.pendingEntriesEmpEmailId != ""){
    const cc = 'arun-pandian.ramakrishnan@rntbci.com; hariprasad.muniraj@rntbci.com';
    const subject = 'NX Activity Tracker Timesheet Update Required – Pending Entries Identified';
    const body = `Dear Employee,\n
  You have pending timesheet entries that need to be updated.\n
  Please log in to the system and complete them at the earliest.\n
  If already submitted, kindly ignore this message.\n
  \n
  Regards,\n
  Timesheet System\n
  (This is an auto-generated email. Please do not reply.)`;
  
    window.location.href = `mailto:${this.pendingEntriesEmpEmailId}?cc=${encodeURIComponent(cc)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }
  else{
    alert("No Pending Entries Found...!");
  }
  
  setTimeout(() => {
    this.loading = false;    
  }, 2000); // 2000 ms = 2 seconds 
}


}
