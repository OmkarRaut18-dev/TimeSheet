import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import { HomeService } from '../../Service/home.service';
import Chart from 'chart.js/auto';
import { stat } from 'fs';
import { LoaderComponent } from '../loader/loader.component';
import { HttpClient } from '@angular/common/http';
import { blob } from 'stream/consumers';
import { saveAs } from 'file-saver'; 
import { LoginService } from '../../Service/login.service';

@Component({
  selector: 'app-homepage',
  standalone: true,
  imports: [CommonModule,FormsModule,FullCalendarModule,LoaderComponent],
  templateUrl: './homepage.component.html',
  styleUrl: './homepage.component.css'
})
export class HomepageComponent {

dates: { display: string; value: string }[] = [];
activities: any[] = [];
selectedDates: { [key: string]: boolean } = {};
usedDates: Set<string> = new Set();
weekendDates: Set<string> = new Set();
department:string ='';
bowpNumber:string ='';
projectActivity:string ='';
status: string = '';
username: string ='';
workingDays:string='';
leaveDays:string='';
holidays:string='';
activityChart: any;
dateStatusMap: { [key: string]: string } = {}; 
counter : number=0;
savedEntryMessage : boolean = false;
savedEntries :{department:string;bowpNumber:string;status:string;projectActivity:string;dates: string;fteCostTransferTo:string; }[]=[];
modalBody = true;
editDepartment:string ='';
editBowpNumber:string ='';
editProjectActivity:string ='';
editStatus: string = '';
editFTETransferToCostCode ='';
displayDateToBeEdited : string= '';
loading : boolean = false;
FTETransferToCostCode :string = '';
FTETransferFromCostCode : string = 'ABC111';
isRole:boolean =false;
backToTableDisable=false;
months = [
  { name: 'January', value: 0 },
  { name: 'February', value: 1 },
  { name: 'March', value: 2 },
  { name: 'April', value: 3 },
  { name: 'May', value: 4 },
  { name: 'June', value: 5 },
  { name: 'July', value: 6 },
  { name: 'August', value: 7 },
  { name: 'September', value: 8 },
  { name: 'October', value: 9 },
  { name: 'November', value: 10 },
  { name: 'December', value: 11 }
];

years: number[] = [];
selectedMonth:number = new Date().getMonth();
selectedYear:number = new Date().getFullYear();
previousMonth: number = new Date().getMonth();
previousYear: number = new Date().getFullYear();
currentYear: number = new Date().getFullYear();    
currentMonth: number = new Date().getMonth();  


constructor(private homService: HomeService, private http :HttpClient, private loginservice: LoginService){}

  ngOnInit() {
  this.loading= false;
    this.generateYearOptions();
    this.previousMonth = this.selectedMonth;
    this.previousYear = this.selectedYear;  
    
    this.generateDatesForCurrentMonth(this.selectedYear, this.selectedMonth);
    
    // this.isRole = this.loginservice.getIsRoleAdmin();

    if (typeof window !== 'undefined') {
      const storedUser = sessionStorage.getItem('user');
      if (storedUser) {
        const userInfo = JSON.parse(storedUser);
       this.username = userInfo;
      }

      const getRole = sessionStorage.getItem('details');
      if(getRole){
        const userInfo = JSON.parse(getRole);
        if(userInfo.role=='admin'){
          this.isRole= true;
        }
        else{
          this.isRole = false;
        }
      }

    }

    this.fetchUsedDates(this.selectedYear, this.selectedMonth);
    this.fetchStatusCounts(this.selectedYear,this.selectedMonth,this.username);
    this.fetchReviewDataForMonth();
  }

  generateYearOptions() {
    const currentYear = new Date().getFullYear();
    const startYear = 2025;
    const endYear = currentYear + 1; 
    this.years = [];
  
    for (let year = startYear; year <= endYear; year++) {
      this.years.push(year);
    }
  }

  isFutureYear(year:number):boolean{
    
    if (year === this.currentYear) {
      return false;
    }
    else{
      return true;
    }
  }

  closeMessage(){
    this.savedEntryMessage=false;
  }


  generateDatesForCurrentMonth(year: number, month: number) {
    this.savedEntries =[];
    this.dates =[];
    this.weekendDates.clear();
    month = Number(month);   
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0); // Last day of current month
    

    const dateArray: { display: string, value: string }[] = [];
    let currentDate = firstDay;

    while (currentDate <= lastDay) {
      const day = currentDate.getDate().toString().padStart(2, '0');
      const monthName = currentDate.toLocaleString('default', { month: 'short' }); // "Apr", "May"
      const dayName = currentDate.toLocaleString('default', { weekday: 'short' }); // "Mon", "Tue"
      const display = `${day}-${monthName} (${dayName})`; // For UI
      const value = `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}-${currentDate.getDate().toString().padStart(2, '0')}`;  
      dateArray.push({ display, value });
      if(dayName == "Sat" || dayName == "Sun"){
        this.weekendDates.add(value);         
      }  
      currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 1);
    }

    this.dates = dateArray;   
  }

  isFutureMonth(month: number): boolean {
    const selectedYear = Number(this.selectedYear);

    // If selected year is the current year
    if (selectedYear === this.currentYear) {
      // Disable future months
      if (month > this.currentMonth) {
        return true;
      }
      // Disable months that are more than 3 months older
      if (month < this.currentMonth - 3) {
        return true;
      }
    }
  
    // If selected year is in the future, disable all months
    if (selectedYear > this.currentYear) {
      return true;
    }
  
    // If selected year is in the past, allow all months (or adjust logic if needed)
    return false;
  }
  
  onSaveActivity(form: NgForm) {

    if (!form.valid) {
      alert('Please fill all required fields before submitting.');
      return;
    }

    const selectedDateList = Object.keys(this.selectedDates).filter(date => this.selectedDates[date]);  
    
    const activity = {
      department: this.department,
      bowpNumber: this.bowpNumber,
      fteCostTransferFrom: this.FTETransferFromCostCode,
      fteCostTransferTo: this.FTETransferToCostCode,
      projectActivity: this.projectActivity,
      dates: selectedDateList,
      status: this.status,
      userId: this.username
    };
    this.loading = true;
    this.homService.saveActivity(activity).subscribe({
      next:(response) =>{ 
      this.clearForm();
      this.fetchUsedDates(this.selectedYear,this.selectedMonth);
      this.fetchStatusCounts(this.selectedYear,this.selectedMonth,this.username);
      this.savedEntryMessage = true;
      setTimeout(()=>{
        this.savedEntryMessage = false;
      },4000);
      this.loading = false;
      },
      error:(error)=>{
        this.loading = false;
        console.error('Failed to save activity:',error);
      }
    });    
  }

  clearForm() {
    this.department = '';
    this.bowpNumber = '';
    this.projectActivity = '';
    this.selectedDates = {};
    this.status ='';
    this.FTETransferToCostCode='';
  }
  

  isStatusDisabled(): boolean {
    const isLeaveOrHoliday = this.status === 'Leave' || this.status === 'Holiday';
    if (isLeaveOrHoliday) {
      this.department = '';
      this.bowpNumber = '';
      this.projectActivity = '';
      this.FTETransferToCostCode ='';
      return true;
    }

    return false;
  }

  isEditableStatusDisabled(): boolean {
    const isLeaveOrHoliday = this.editStatus === 'Leave' || this.editStatus === 'Holiday';
    if (isLeaveOrHoliday) {
      this.editDepartment = '';
      this.editBowpNumber = '';
      this.editProjectActivity = '';
      this.editFTETransferToCostCode='';
      return true;
    }

    return false;
  }

  onMonthYearChange() {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth(); // 0-indexed
  
    const selectedMonth = Number(this.selectedMonth);
    const selectedYear = Number(this.selectedYear);
    // Block future months and years
  if (selectedYear > currentYear ||
    (selectedYear === currentYear && selectedMonth > currentMonth)) 
    {
     alert("Please select the current or a previous month and year.");
    this.selectedMonth = this.previousMonth;
    this.selectedYear = this.previousYear;
    return;
    }
    this.generateDatesForCurrentMonth(this.selectedYear, this.selectedMonth);
    this.fetchUsedDates(this.selectedYear, this.selectedMonth); // From backend
    this.fetchStatusCounts(this.selectedYear,this.selectedMonth,this.username);
    this.fetchReviewDataForMonth();
  }

  fetchUsedDates(year: number, month: number) {
  
    this.counter=0;
    month = Number(month);
    const formattedMonth = (month + 1).toString().padStart(2, '0');
    this.loading = true;
    this.homService.savedDates(this.username).subscribe({
      next: (response: { entrydates: string, status: string }[]) => {
        
        response.forEach(entry=>{
          const {entrydates,status}=entry;
          if(entrydates.startsWith(`${year}-${formattedMonth}`)){
            this.usedDates.add(entrydates);
            this.dateStatusMap[entrydates] = status;
            this.counter++;
          }
        })
        this.loading = false;
          console.log(this.counter);
      },
      error: (error) => {
        this.loading = false;
        console.log("Failed to fetch the dates from database", error);
      }
    });
  }

  isWeekend(dateStr: string): boolean {
    const date = new Date(dateStr);
    const day = date.getDay();
    return day === 0 || day === 6; // Sunday (0) or Saturday (6)
  }

  fetchStatusCounts(year:number,month:number,userId:string){
  month = Number(month);
  const formattedMonth = (month + 1).toString().padStart(2, '0');

  const requestDTO = {
    year: year,
    month:formattedMonth,
    userId:userId,
  }
    this.loading = true;
      this.homService.statusCount(requestDTO).subscribe({
      next:(response)=>{
        console.log(response);
        this.workingDays = response.workingDays;
        this.leaveDays = response.leaveDays;
        this.holidays = response.holidays;
        // Convert to numbers and update chart
        const working = Number(this.workingDays);
        const leave = Number(this.leaveDays);
        const holiday = Number(this.holidays);
        this.renderChart(working, leave, holiday);
        this.loading = false;
      },
      error:(error)=>{
        this.loading = false;
      console.error(error);
      }
    });

  }

  renderChart(working: number, leave: number, holiday: number): void {
    const ctx = document.getElementById('activityChart') as HTMLCanvasElement;

    if (this.activityChart) {
      this.activityChart.destroy(); // Destroy previous chart to avoid duplication
    }

    this.activityChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Working Days', 'Leave Days', 'Holidays'],
        datasets: [{
          label: 'Status Count',
          data: [working, leave, holiday],
          backgroundColor: ['#4caf50', '#ff9800', '#03a9f4']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  }

  isAllDatesSubmitted(): boolean {
    const weekend = this.weekendDates.size;
    const totalMonthDays = this.dates.length;
    const submittedDays = this.counter;
    const totalSubmittedDays =totalMonthDays-weekend;
    if(totalSubmittedDays == submittedDays){
      return true;
    }
    return false;
  }
  
  fetchReviewDataForMonth(){
    const month = Number(this.selectedMonth); 
    const formattedMonth = (month + 1).toString().padStart(2, '0');
    this.loading = true;
    this.homService.getReviewData(this.selectedYear,Number(formattedMonth),this.username).subscribe({
      next:(response)=>{
      // Clear the previous entries if needed
      this.savedEntries = [];

      // Check if response is an array
      if (Array.isArray(response)) {
        response.forEach((item: any) => {
          const activity = {
            department: item.department,
            bowpNumber: item.bowpNumber,
            status: item.status,
            projectActivity: item.projectActivity,
            dates: item.date,
            fteCostTransferTo: item.ftetransferToCostCode
          };
          this.savedEntries.push(activity);
        });
      }
      this.loading = false;
      console.log(this.savedEntries);
      },
      error:(error)=>{
        this.loading = false;
      }
    });
    this.loading = false;
  }

  editTheEntries(department:string, bowpnumber:string,status:string,projectactivity:string,dates:string, fteCostTransferTo:string){ 
    this.modalBody=false;
    this.backToTableDisable = true;
    this.editDepartment = department,
    this.editBowpNumber= bowpnumber,
    this.editProjectActivity= projectactivity,    
    this.editStatus = status,
    this.selectedDates = {};
    this.displayDateToBeEdited = dates;
    this.editFTETransferToCostCode = fteCostTransferTo;
    dates.split(',').forEach(date => {
    this.selectedDates[date.trim()] = true;
  });
  }

  saveEditedActivity(form: NgForm){
    if (!form.valid) {
      alert('Please fill all required fields before submitting.');
      return;
    }

    const selectedDateList = Object.keys(this.selectedDates).filter(date => this.selectedDates[date]);  
    
    const activity = {
      department: this.editDepartment,
      bowpNumber: this.editBowpNumber,
      fteCostTransferFrom: this.FTETransferFromCostCode,
      fteCostTransferTo: this.editFTETransferToCostCode,
      projectActivity: this.editProjectActivity,
      dates: selectedDateList,
      status: this.editStatus,
      userId: this.username
    };
    this.loading = true;
    this.homService.updateActivity(activity).subscribe({
      next:(response) =>{ 
      this.clearForm();
      this.fetchUsedDates(this.selectedYear,this.selectedMonth);
      this.fetchStatusCounts(this.selectedYear,this.selectedMonth,this.username);
      this.savedEntryMessage = true;
      setTimeout(()=>{
        this.savedEntryMessage = false;
      },4000);
      this.modalBody=true;
      this.backToTableDisable = false;
      this.fetchReviewDataForMonth();
      this.loading = false;
      },
      error:(error)=>{
        this.loading = false;
        console.error('Failed to save activity:',error);
      }
    });    
  }

  navigateToTable(){
    this.modalBody = true;    
    this.backToTableDisable = false;
  }

  onDepartmentChange(selectedDept: string) {
    switch (selectedDept) {
      case 'PE':
        this.bowpNumber = 'PE-BOWP-1';
        this.FTETransferToCostCode = 'ABC121';
        break;
      case 'DGPEC':
        this.bowpNumber = 'DGPEC-BOWP-2';
        this.FTETransferToCostCode = 'ABC122';
        break;
      case 'XK0':
        this.bowpNumber = 'XK0-BOWP-3';
        this.FTETransferToCostCode = 'ABC123';
        break;
      case 'BODY':
        this.bowpNumber = 'BODY-BOWP-4';
        this.FTETransferToCostCode = 'ABC124';
        break;
      case 'CHASSIS':
        this.bowpNumber = 'CHASSIS-BOWP-5';
        this.FTETransferToCostCode = 'ABC125';
        break;
      case 'VEHICLE CAE':
        this.bowpNumber = 'CAE-BOWP-6';
        this.FTETransferToCostCode = 'ABC126';
        break;
      case 'Other':
        this.bowpNumber = 'OTHER-BOWP';
        this.FTETransferToCostCode = 'ABC127';
        break;
      default:
        this.bowpNumber = '';
    }
  }
  
  onEditDepartmentChange(selectedDept: string) {
    switch (selectedDept) {
      case 'PE':
        this.editBowpNumber = 'PE-BOWP-1';
        this.editFTETransferToCostCode = 'ABC121';
        break;
      case 'DGPEC':
        this.editBowpNumber = 'DGPEC-BOWP-2';
        this.editFTETransferToCostCode = 'ABC122';
        break;
      case 'XK0':
        this.editBowpNumber = 'XK0-BOWP-3';
        this.editFTETransferToCostCode = 'ABC123';
        break;
      case 'BODY':
        this.editBowpNumber = 'BODY-BOWP-4';
        this.editFTETransferToCostCode = 'ABC124';
        break;
      case 'CHASSIS':
        this.editBowpNumber = 'CHASSIS-BOWP-5';
        this.editFTETransferToCostCode = 'ABC125';
        break;
      case 'VEHICLE CAE':
        this.editBowpNumber = 'CAE-BOWP-6';
        this.editFTETransferToCostCode = 'ABC126';
        break;
      case 'Other':
        this.editBowpNumber = 'OTHER-BOWP';
        this.editFTETransferToCostCode = 'ABC127';
        break;
      default:
        this.editBowpNumber = '';
    }
  }

  generateReport(){
    this.loading = true;
    const year = this.selectedYear;
    const month = Number(this.selectedMonth);
    const reportMonth = month+1;
    const userId = this.username;
    // const url = `http://localhost:8080/reportGeneration?year=${year}&month=${reportMonth}&userId=${userId}`;
     const url = `http://10.244.13.255:8082/NxActivity/reportGeneration?year=${year}&month=${reportMonth}&userId=${userId}`;
  
    this.http.get(url, { responseType: 'blob' }).subscribe(blob => {
      const selectedMonthName = this.months.find(month => month.value === Number(this.selectedMonth));
      const monthName = selectedMonthName?.name || 'UnknownMonth';
      saveAs(blob, 'NXACtivityTracker_FY '+this.selectedYear+'-'+monthName);
      this.loading = false;
    }, error => { 
      console.error('Error downloading the report', error);
      this.loading = false;
    });
    this.loading = false;
  }

  clearFields(){
    this.editDepartment = '';
    this.editBowpNumber= '';
    this.editProjectActivity= '';   
    this.editStatus = '';
    this.displayDateToBeEdited = '';
    this.editFTETransferToCostCode = '';
    this.modalBody = true;    
    this.backToTableDisable = false;
  }

}
