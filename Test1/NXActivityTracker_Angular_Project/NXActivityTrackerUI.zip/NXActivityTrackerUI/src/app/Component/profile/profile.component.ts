import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, Validators, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { passwordValidator } from '../../password.validator';
import { HomeService } from '../../Service/home.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule,ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {

  user: any = {}; // Will hold username, email, fullName

  constructor(private http: HttpClient, public fb:FormBuilder, public homeService: HomeService) {}

  ngOnInit() {
    if (typeof window !== 'undefined') {
      const storedUser = sessionStorage.getItem('details');
      if(storedUser){
        const userInfo = JSON.parse(storedUser); // Assuming stored data is a JSON string
        this.user = {
          username: userInfo.username || '',
          firstname: userInfo.firstName || '',
          lastname: userInfo.lastName || '',
          role: userInfo.role || '',
          email: userInfo.email || '',
          createdAt: userInfo.createdAt ||'',
          rnId:userInfo.rnNumber ||'',
          designation:userInfo.designation ||''
        };
      }
      
    }
  }

  changePasswordForm = this.fb.group({
    userId:['',[Validators.required]],
    password:['',[Validators.required,Validators.minLength(5)]],
    confirmPassword:['',[Validators.required]]
  },{validators:passwordValidator})

  get userIdForPassword(){
    return this.changePasswordForm.get('userId');
  }
 
  get setPassword(){
    return this.changePasswordForm.get('password');
  }

  get confirmPassForChangePass(){
    return this.changePasswordForm.get('confirmPassword');
  }

  onResetchangePasswordForm() {
    this.changePasswordForm.reset();
  }

  onSubmitChangePassword() {
    console.log("api hitted..");
    const formData = this.changePasswordForm.value;
 
    if (!formData.userId) {
      console.error('User ID is required to change the password.');
      return;
    }
    if (!formData.password || !formData.confirmPassword) {
      console.error('Both new password and confirm password are required.');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      console.error('New password and confirm password do not match.');
      return;
    }
 
    this.homeService.updateUserPassword(formData.userId, formData.password).subscribe({
      next: (response:any) => {
        console.log('Password Successfully Updated', response);      
        this.onResetchangePasswordForm();
        alert("Password Updated Successfully");
      },
      error: (error:any) => {
        console.error('Failed to update password', error);        
        this.onResetchangePasswordForm();
        alert("Unable to updated password");
      },
    });
  }

}
