import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userData = new BehaviorSubject<{ firstName: string, lastName: string } | null>(null);
  private userRole = new BehaviorSubject<string | null>(null);

  user$ = this.userData.asObservable();
  role$ = this.userRole.asObservable();

  setUser(firstName: string, lastName: string,role: string) {
    this.userData.next({ firstName, lastName });
    this.userRole.next(role);
    if (typeof window !== 'undefined') {        
        sessionStorage.setItem('firstname_lastname', JSON.stringify({ firstName, lastName }));
        sessionStorage.setItem('details', JSON.stringify({ role }));
      }         
  }

  getUser() {
    return this.userData.getValue();
  }

  getRole() {
    return this.userRole.getValue();
  }
}
