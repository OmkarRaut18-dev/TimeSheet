import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable,BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: HttpClient) { }

  // private apiSaveActivity : string ='http://localhost:8080/saveActivity';

  // private apiGetSavedDates : string ='http://localhost:8080/getUsedDates';

  // private apiGetStatusCounts : string ='http://localhost:8080/getStatus';

  // private apiGetReviewDataForMonth : string ='http://localhost:8080/reviewdata';

  // private apiUpdateActivity : string ='http://localhost:8080/editActivities';

  // private updatePassword : string = 'http://localhost:8080/updatePassword';

  private apiSaveActivity : string ='http://10.244.13.255:8082/NxActivity/saveActivity';

  private apiGetSavedDates : string ='http://10.244.13.255:8082/NxActivity/getUsedDates';

  private apiGetStatusCounts : string ='http://10.244.13.255:8082/NxActivity/getStatus';

  private apiGetReviewDataForMonth : string ='http://10.244.13.255:8082/NxActivity/reviewdata';

  private apiUpdateActivity : string ='http://10.244.13.255:8082/NxActivity/editActivities';

  private updatePassword : string = 'http://10.244.13.255:8082/NxActivity/updatePassword';


  saveActivity(projectActivity:any):Observable<any>{
    return this.http.post(this.apiSaveActivity,projectActivity);
  }

  savedDates(userId:any):Observable<any>{
    return this.http.get<any>(`${this.apiGetSavedDates}?userId=${userId}`);
  }

  statusCount(yearMonthUserId : any):Observable<any>{
    return this.http.post<any>(this.apiGetStatusCounts,yearMonthUserId);
  }

  getReviewData(year:number, month:number, id: string):Observable<any>{
    const params = {
      year: year,
      month: month,
      userId: id
    };
    return this.http.get<any>(this.apiGetReviewDataForMonth,{params});
  }

  updateActivity(projectActivity:any):Observable<any>{
    return this.http.put(this.apiUpdateActivity,projectActivity);
  }

  updateUserPassword(userId:string, password:string):Observable<any>{
    const params = new HttpParams()
      .set('userId',userId)
      .set('password',password);
      return this.http.get(this.updatePassword, { params, responseType: 'text' });
  }
}
