import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  // private loginApi = 'http://localhost:8080/userlogin';
  private loginApi = 'http://10.244.13.255:8082/NxActivity/userlogin';

  constructor(private http: HttpClient) { }

  private isAuthenticated = false;
  private authStatusSource = new BehaviorSubject<boolean>(false);
  authStatus = this.authStatusSource.asObservable();

  isRoleAdmin : boolean = false;

  login(userId: string, password: string): Observable<any> {
    const body = { userId, password };
    return this.http.post<any>(this.loginApi, body);
  }

  loginTrack() {
    this.isAuthenticated = true;
    this.authStatusSource.next(this.isAuthenticated);
  }
  
  logoutTrack() {
    this.isAuthenticated = false;
    this.authStatusSource.next(this.isAuthenticated);
   // Check if window is defined (this ensures you're in the browser environment)
  if (typeof window !== 'undefined') {
    sessionStorage.removeItem('user'); 
    sessionStorage.removeItem('firstname_lastname');
    sessionStorage.removeItem('details');
  } //Remove the user item when logging out
  }
  

  isLoggedIn(): boolean {
    // First check memory
    if (this.isAuthenticated) {
      return true;
    }  
    // Check if we are in browser (because sessionStorage is browser-only)
    if (typeof window !== 'undefined') {
      const user = sessionStorage.getItem('user');
      if (user) {
        this.isAuthenticated = true; // Restore memory
        return true;
      }
    }  
    return false; // Not logged in
  }

  setIsRoleAdmin(value:boolean){
    this.isRoleAdmin = value;
  }
  
  getIsRoleAdmin(){
    return this.isRoleAdmin;
  }

}
