import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  // private apiListOfdeveloper ='http://localhost:8080/fetchDevelopersDetails';
  // private apiCreateUser = 'http://localhost:8080/createNewUser';
  // private apiRemoveUser ='http://localhost:8080/removeUser';

  private apiListOfdeveloper ='http://10.244.13.255:8082/NxActivity/fetchDevelopersDetails';
  private apiCreateUser = 'http://10.244.13.255:8082/NxActivity/createNewUser';
  private apiRemoveUser ='http://10.244.13.255:8082/NxActivity/removeUser';

  constructor(private http: HttpClient) { }

  fetchListOfDeveloper(): Observable<any>{
    return this.http.get<any>(this.apiListOfdeveloper);
  }

  addUserDetails(userData: any):Observable<any>{
    const payload = {
      userId: userData.user_id,
      firstName: userData.first_name,
      lastName: userData.last_name,
      email: userData.email,
      role: userData.role,
      createdAt: userData.created_at,
      password: userData.password,
      rnNumber: userData.RNID,
      designation: userData.designation
    };
    
    return this.http.post(this.apiCreateUser,payload)
  }

  removeUser(userId: String):Observable<any>{
    return this.http.delete<any>(this.apiRemoveUser,{
      body: userId,
      responseType: 'text' as 'json'
    });
  }


}
